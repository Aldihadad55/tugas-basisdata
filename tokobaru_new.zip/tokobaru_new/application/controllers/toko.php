<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Toko extends CI_Controller {

	
	public function index()
	{
		$this->load->view('template/header');
		$this->load->view('template/navigasi');
		$this->load->view('a');
		$this->load->view('template/footer');

	}

	//=================================================================

	public function pelanggan()
	{
		$data ['pelanggan'] = $this->mtoko->pelanggannew() -> result();
		$this->load->view('template/header');
		$this->load->view('template/navigasi');
		$this->load->view('pelanggan',$data);
		$this->load->view('template/footer');
		
	}

	public function hpelanggan($id_pelanggan)
	{
	$data=array('id_pelanggan'=>$id_pelanggan);
		$this->mtoko->hpsbarang($data,'pelanggan');
		redirect ('/toko/pelanggan');
	
	}

	public function inptpelanggan()
	{
		$this->load->view('template/header');
		$this->load->view('template/navigasi');
		$this->load->view('inputpelanggan');
		$this->load->view('template/footer');
	}

	public function formubhpelanggan($id_pelanggan)
	{
		$where=array('id_pelanggan'=>$id_pelanggan);
		$data ['edit'] = $this->mtoko->editpelanggan($where,'pelanggan') -> result();
		$data ['pelanggan'] = $this->mtoko->pelanggannew() -> result();
		$this->load->view('template/header');
		$this->load->view('template/navigasi');
		$this->load->view('ubahpelanggan',$data);
		$this->load->view('template/footer');
		                                                                                  
	}

	public function ubhpelanggan()
	{
		$id_pelanggan=$this->input->post('id_pelanggan');
		$nama_pelanggan=$this->input->post('nama_pelanggan');
		$email=$this->input->post('email');
		$nomor_telepon=$this->input->post('nomor_telepon');
		$password=$this->input->post('password');

		$where = array('id_pelanggan' => $id_pelanggan );

			$data= array('id_pelanggan' => $id_pelanggan,
						'nama_pelanggan' => $nama_pelanggan,
						 'email' => $email,
						'nomor_telepon' => $nomor_telepon,
						'password' => $password);

			$this->mtoko->ubahpelanggan($where,$data,'pelanggan');
			redirect('toko/pelanggan');

	}




	public function formpelanggan()
	{
		$nama_pelanggan=$this->input->post('nama_pelanggan');
		$email=$this->input->post('email');
		$nomor_telepon=$this->input->post('nomor_telepon');
		$password=$this->input->post('password');

			$data= array('nama_pelanggan' => $nama_pelanggan,
						 'email' => $email,
						'nomor_telepon' => $nomor_telepon,
						'password' => $password);

			$this->mtoko->tmbpelanggan($data,'pelanggan');
			redirect('toko/pelanggan');

	}

	//====================================================

	public function tbarang()
	{	$data ['barang'] = $this->mtoko->barangnew() -> result();
		$this->load->view('template/header');
		$this->load->view('template/navigasi');
		$this->load->view('barang',$data);
		$this->load->view('template/footer');
			
	}
	public function formtbarang()
	{
		$this->load->view('template/header');
		$this->load->view('template/navigasi');
		$this->load->view('formtbarang');
		$this->load->view('template/footer');
		
		
	}
	public function inputbarang()
	{
		$nama_barang=$this->input->post('nama_barang');
		$jumlah=$this->input->post('jumlah');
		$satuan=$this->input->post('satuan');
		$harga_barang=$this->input->post('harga_barang');

			$data= array('nama_barang' => $nama_barang,
						 'jumlah' => $jumlah,
						'satuan' => $satuan,
						'harga_barang' => $harga_barang);

			$this->mtoko->tmbbarang($data,'barang');
			redirect('toko/tbarang');

	}

	public function hbarang($id_barang)
	{
		$data=array('id_barang'=>$id_barang);
		$this->mtoko->hpsbarang($data,'barang');
		redirect ('/toko/tbarang');

	}

	public function ubhbarang($id_barang)
	{
		$where=array('id_barang'=>$id_barang);
		$data ['edit'] = $this->mtoko->edit($where,'barang') -> result();
		$data ['barang'] = $this->mtoko->barangnew() -> result();
		$this->load->view('template/header');
		$this->load->view('template/navigasi');
		$this->load->view('ubahbarang',$data);
		$this->load->view('template/footer');
	}
	 public function edit_barang()
	{
		$id_barang=$this->input->post('id_barang');
		$nama_barang=$this->input->post('nama_barang');
		$jumlah=$this->input->post('jumlah');
		$satuan=$this->input->post('satuan');
		$harga_barang=$this->input->post('harga_barang');

		$where=array('id_barang'=>$id_barang);

			$data= array('nama_barang' => $nama_barang,
						 'jumlah' => $jumlah,
						'satuan' => $satuan,
						'harga_barang' => $harga_barang);
			$this->mtoko->ubahbrg($where,$data,'barang');
			redirect ('/toko/tbarang');

	}
	//======================

	public function pembeli()
	{
		# code...
	}




}
