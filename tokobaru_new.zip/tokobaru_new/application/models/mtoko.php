<?php	

class Mtoko extends CI_Model {


//========================================


	public function pelanggannew()
	{
	return $this->db->get('pelanggan');	
	}

	public function tmbpelanggan($data,$table)
	{
	$this->db->insert($table,$data);
	
	}

	public function hpspelanggan($data,$table)

	{
	$this->db->where($data);
	return $this->db->delete($table);

	}

	public function ubahpelanggan($where,$data,$table)
	{
		$this->db->where($where);
	return $this->db->update($table,$data);

	}

	public function editpelanggan($where,$table)
	{
		$this->db->where($where);
return $this->db->get($table);
	}

	//=-============================================

public function barangnew(){
return $this->db->get('barang');

}
public function tmbbarang($data,$table){

$this->db->insert($table,$data);

}
public function hpsbarang($data,$table)
{
$this->db->where($data);
return $this->db->delete($table);
}

public function edit($where,$table)
{
$this->db->where($where);
return $this->db->get($table);
}

public function ubahbrg($where,$data,$table)
{
$this->db->where($where);
return $this->db->update($table,$data);

}




}
?>