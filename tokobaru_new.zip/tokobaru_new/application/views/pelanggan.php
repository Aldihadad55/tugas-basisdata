<div class="card" style="width:80%; margin: auto;">
  <div class="card-header">
    Data Pelanggan
  </div>
<br>
<a href="<?= site_url('toko/inptpelanggan')  ?>" class="btn btn-primary btn-sm mb-2">
				<i class="fas fa-plus "></i>
				Tambah pelanggan
			</a>
  <div class="card-body">
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">NO</th>
      <th scope="col">Nama Pelnggan</th>
      <th scope="col">Email</th>
      <th scope="col">password</th>
      <th scope="col">Nomor HP</th>
      <th scope="col">Opsi</th>
    </tr>
  </thead>
  <tbody>
    <?php $no = 1; ?>
    <?php foreach ($pelanggan as $brg):?>

    <tr>
      <th scope="row"><?= $no ?></th>
      <td><?= $brg ->nama_pelanggan  ?></td>
      <td><?= $brg ->email  ?></td>
      <td><?= $brg ->password  ?></td>
      <td><?= $brg ->nomor_telepon  ?></td>
   
      <td>
      	<a href="<?=site_url('/toko/hpelanggan/').$brg->id_pelanggan;  ?>" class="btn btn-danger">Hapus</a>
      	<a href="<?=site_url('/toko/formubhpelanggan/').$brg->id_pelanggan;  ?>" class="btn btn-warning">Ubah</a>
      	
      </td>
    </tr>
    <?php $no++; ?>
<?php endforeach ?>



  </tbody>
</table>
  </div>
</div>