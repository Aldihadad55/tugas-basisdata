<div class="margin" style="text-align: center; margin-top: 25%;"><h1>Selamat Datang</h1>
<h3>Silakan Lihat Barang</h3></div>
