<title>Tambah Pelnggan</title>
<div class="card shadow mb-4" style="width: 85%; margin: auto; margin-top: 20px;">
    <div class="card-header py-3">
        <h3 class="m-0 font-weight-bold text-primary">Tambah pelanggan</h3>
    </div>
    <div class="card-body">
    
        <form action="<?= site_url('toko/formpelanggan') ?>" method="post">
		<div class="form-group">
			<label for="nama_pelanggan">Nama </label>
			<input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" placeholder="Masukkan Nama" required="">
		</div>
		
		<div class="form-group">
			<label for="email">Email</label>
			<input type="Email" class="form-control" id="email" name="email"  placeholder="Masukan Jumlah" required="">
		</div>
		<div class="form-group">
			<label for="nomor_telepon">Nomor_Telepon </label>
			<input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon" placeholder="Masukkan Satuan" required="">
		</div>
		<div class="form-group">
			<label for="password">Password</label>
			<input type="password" class="form-control" id="password" name="password" placeholder="Masukan Haraga" required="">
		</div>
		<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	</div>
</div>