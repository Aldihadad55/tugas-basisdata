<div class="card" style="width:80%; margin: auto;">
  <div class="card-header">
    Data Barang
  </div>
<br>
<a href="<?= site_url('toko/formtbarang')  ?>" class="btn btn-primary btn-sm mb-2">
				<i class="fas fa-plus "></i>
				Tambah Barang
			</a>
  <div class="card-body">
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">NO</th>
      <th scope="col">Nama Barang</th>
      <th scope="col">Jumlah</th>
      <th scope="col">Satuan</th>
      <th scope="col">Harga</th>
      <th scope="col">Opsi</th>
    </tr>
  </thead>
  <tbody>
    <?php $no = 1; ?>
    <?php foreach ($barang as $brg):?>

    <tr>
      <th scope="row"><?= $no ?></th>
      <td><?= $brg ->nama_barang  ?></td>
      <td><?= $brg ->jumlah  ?></td>
      <td><?= $brg ->satuan  ?></td>
      <td><?= $brg ->harga_barang  ?></td>
   
      <td>
      	<a href="<?=site_url('/toko/hbarang/').$brg->id_barang;  ?>" class="btn btn-danger">Hapus</a>
      	<a href="<?=site_url('/toko/ubhbarang/').$brg->id_barang;  ?>" class="btn btn-warning">Ubah</a>
      	
      </td>
    </tr>
    <?php $no++; ?>
<?php endforeach ?>



  </tbody>
</table>
  </div>
</div>