<title>Ubah Barang</title>
<div class="card shadow mb-4" style="width: 85%; margin: auto; margin-top: 20px;">
    <div class="card-header py-3">
        <h3 class="m-0 font-weight-bold text-primary">Ubah Barang</h3>
    </div>
    <div class="card-body">
    
        <form action="<?= site_url('toko/edit_barang/') ?>" method="post">
        	<div class="form-group">
			<label for="id_barang">id </label>
			<input type="text" class="form-control" id="id_barang" name="id_barang" required="">
		</div>
		<div class="form-group">
			<label for="nama_barang">Nama </label>
			<input type="text" class="form-control" id="nama_barang" name="nama_barang" placeholder="Masukkan Nama" required="">
		</div>
		
		<div class="form-group">
			<label for="jumlah">Jumlah</label>
			<input type="number" class="form-control" id="jumlah" name="jumlah"  placeholder="Masukan Jumlah" required="">
		</div>
		<div class="form-group">
			<label for="satuan">Satuan </label>
			<input type="text" class="form-control" id="satuan" name="satuan" placeholder="Masukkan Satuan" required="">
		</div>
		<div class="form-group">
			<label for="harga_barang">Harga Barang</label>
			<input type="harga_barang" class="form-control" id="harga_barang" name="harga_barang" placeholder="Masukan Haraga" required="">
		</div>
		<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	</div>
</div>